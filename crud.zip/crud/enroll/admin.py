from django.contrib import admin
from .models import User

# Register your models here.
@admin.register(User)
class UserClass(admin.ModelAdmin):
    list_display=('uname','email','password')
